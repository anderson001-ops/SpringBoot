package com.sena.clase1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase1Application {

	public static void main(String[] args) {
		SpringApplication.run(Clase1Application.class, args);
	}

}
